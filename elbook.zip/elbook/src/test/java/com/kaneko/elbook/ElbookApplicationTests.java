package com.kaneko.elbook;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ElbookApplicationTests {

	@Test
	void contextLoads() {
	}

}
