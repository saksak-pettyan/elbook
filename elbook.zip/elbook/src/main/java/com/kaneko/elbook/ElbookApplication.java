package com.kaneko.elbook;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ElbookApplication {

    public static void main(String[] args) {
        SpringApplication.run(ElbookApplication.class, args);
    }
}
